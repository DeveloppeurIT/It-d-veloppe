const stats = [
  { number: "500+", label: "Clients" },
  { number: "1000+", label: "Projets" },
  { number: "50+", label: "Experts" },
  { number: "15+", label: "Années d'expérience" }
];

export function Stats() {
  return (
    <section className="bg-blue-600 py-16 px-4">
      <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
        {stats.map((stat, index) => (
          <div key={index} className="text-white">
            <div className="text-4xl font-bold mb-2">{stat.number}</div>
            <div className="text-blue-100">{stat.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}