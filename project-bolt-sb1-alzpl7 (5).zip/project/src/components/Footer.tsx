export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <p>© 2024 Tech Solutions. Tous droits réservés.</p>
      </div>
    </footer>
  );
}