import LiteYouTubeEmbed from 'react-lite-youtube-embed';
import 'react-lite-youtube-embed/dist/LiteYouTubeEmbed.css';
import { motion } from 'framer-motion';

export function VideoSection() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-900">
            Découvrez nos solutions
          </h2>
          
          <div className="aspect-video rounded-xl overflow-hidden shadow-xl">
            <LiteYouTubeEmbed
              id="dQw4w9WgXcQ"
              title="Présentation de nos services"
              poster="maxresdefault"
              webp
            />
          </div>

          <p className="mt-8 text-center text-gray-600 max-w-2xl mx-auto">
            Découvrez comment nos solutions technologiques peuvent transformer votre entreprise
            et accélérer votre croissance.
          </p>
        </motion.div>
      </div>
    </section>
  );
}