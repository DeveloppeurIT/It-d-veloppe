import { ChevronRight } from 'lucide-react';

export function Hero() {
  return (
    <header className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80"
          alt="Technology Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/60"></div>
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          Solutions IT Innovantes
        </h1>
        <p className="text-xl md:text-2xl text-gray-200 mb-8">
          Transformez votre entreprise avec nos services technologiques de pointe
        </p>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-full text-lg font-semibold transition-colors flex items-center mx-auto">
          Découvrir nos services
          <ChevronRight className="ml-2 h-5 w-5" />
        </button>
      </div>
    </header>
  );
}