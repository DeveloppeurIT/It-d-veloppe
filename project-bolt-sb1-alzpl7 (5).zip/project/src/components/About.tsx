export function About() {
  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80"
              alt="Notre équipe"
              className="rounded-2xl shadow-xl"
            />
          </div>
          <div className="space-y-6">
            <h2 className="text-4xl font-bold text-gray-900">
              À Propos de Nous
            </h2>
            <div className="space-y-4">
              <p className="text-lg text-gray-600">
                Depuis 15 ans, Tech Solutions accompagne les entreprises dans leur transformation numérique. Notre expertise technique et notre approche centrée sur le client nous permettent de délivrer des solutions innovantes qui répondent aux défis technologiques d'aujourd'hui.
              </p>
              <p className="text-lg text-gray-600">
                Notre équipe d'experts passionnés combine créativité et expertise technique pour transformer vos idées en solutions concrètes. Nous croyons en l'innovation continue et investissons constamment dans les dernières technologies pour garantir votre succès.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6 pt-4">
              <div className="border-l-4 border-blue-600 pl-4">
                <div className="text-2xl font-bold text-gray-900">100%</div>
                <div className="text-gray-600">Satisfaction client</div>
              </div>
              <div className="border-l-4 border-blue-600 pl-4">
                <div className="text-2xl font-bold text-gray-900">24/7</div>
                <div className="text-gray-600">Support technique</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}