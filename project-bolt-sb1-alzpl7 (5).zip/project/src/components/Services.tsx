import { Code2, Server, Shield, Smartphone, Globe, Users } from 'lucide-react';

const services = [
  { icon: Code2, title: "Développement Logiciel", desc: "Solutions sur mesure adaptées à vos besoins" },
  { icon: Server, title: "Infrastructure Cloud", desc: "Services cloud sécurisés et évolutifs" },
  { icon: Shield, title: "Cybersécurité", desc: "Protection avancée contre les menaces" },
  { icon: Smartphone, title: "Solutions Mobiles", desc: "Applications mobiles performantes" },
  { icon: Globe, title: "Transformation Digitale", desc: "Accompagnement dans votre transition numérique" },
  { icon: Users, title: "Support IT", desc: "Assistance technique 24/7" }
];

export function Services() {
  return (
    <section className="py-20 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16 text-gray-900">
          Nos Services
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <service.icon className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3 text-gray-900">{service.title}</h3>
              <p className="text-gray-600">{service.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}